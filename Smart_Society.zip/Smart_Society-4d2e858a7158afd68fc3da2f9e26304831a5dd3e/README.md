# Smart-Society-Applcation-Project
My smart society application ,Project for Vodafone Idea Internship.
